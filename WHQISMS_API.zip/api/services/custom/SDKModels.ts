/* tslint:disable */
import { Injectable } from '@angular/core';
import { User } from '../../models/User';
import { V_AutoSaveLocalUserGroup } from '../../models/V_AutoSaveLocalUserGroup';
import { V_AutoCompareComputerInfo } from '../../models/V_AutoCompareComputerInfo';
import { V_specificApp } from '../../models/V_specificApp';
import { V_AutoSavePatchInfo } from '../../models/V_AutoSavePatchInfo';
import { ACVUserAuthority } from '../../models/ACVUserAuthority';
import { AutoEOSversion } from '../../models/AutoEOSversion';
import { AutoAPPversion } from '../../models/AutoAPPversion';
import { V_AutoOfcversion } from '../../models/V_AutoOfcversion';
import { V_AutoAPPnamekey } from '../../models/V_AutoAPPnamekey';
import { V_AutoWINversion } from '../../models/V_AutoWINversion';
import { AutoWINversion } from '../../models/AutoWINversion';
import { V_admintotal } from '../../models/V_admintotal';
import { V_admintotaldaybefore } from '../../models/V_admintotaldaybefore';
import { V_UltiomServertotal } from '../../models/V_UltiomServertotal';
import { V_TwoUltiomServertotal } from '../../models/V_TwoUltiomServertotal';
import { V_Computername } from '../../models/V_Computername';

export interface Models { [name: string]: any }

@Injectable()
export class SDKModels {

  private models: Models = {
    User: User,
    V_AutoSaveLocalUserGroup: V_AutoSaveLocalUserGroup,
    V_AutoCompareComputerInfo: V_AutoCompareComputerInfo,
    V_specificApp: V_specificApp,
    V_AutoSavePatchInfo: V_AutoSavePatchInfo,
    ACVUserAuthority: ACVUserAuthority,
    AutoEOSversion: AutoEOSversion,
    AutoAPPversion: AutoAPPversion,
    V_AutoOfcversion: V_AutoOfcversion,
    V_AutoAPPnamekey: V_AutoAPPnamekey,
    V_AutoWINversion: V_AutoWINversion,
    AutoWINversion: AutoWINversion,
    V_admintotal: V_admintotal,
    V_admintotaldaybefore: V_admintotaldaybefore,
    V_UltiomServertotal: V_UltiomServertotal,
    V_TwoUltiomServertotal: V_TwoUltiomServertotal,
    V_Computername: V_Computername,
    
  };

  public get(modelName: string): any {
    return this.models[modelName];
  }

  public getAll(): Models {
    return this.models;
  }

  public getModelNames(): string[] {
    return Object.keys(this.models);
  }
}
