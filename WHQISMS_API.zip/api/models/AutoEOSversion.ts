/* tslint:disable */

declare var Object: any;
export interface AutoEOSversionInterface {
  "EOSname"?: string;
}

export class AutoEOSversion implements AutoEOSversionInterface {
  "EOSname": string;
  constructor(data?: AutoEOSversionInterface) {
    Object.assign(this, data);
  }
  /**
   * The name of the model represented by this $resource,
   * i.e. `AutoEOSversion`.
   */
  public static getModelName() {
    return "AutoEOSversion";
  }
  /**
  * @method factory
  * @author Jonathan Casarrubias
  * @license MIT
  * This method creates an instance of AutoEOSversion for dynamic purposes.
  **/
  public static factory(data: AutoEOSversionInterface): AutoEOSversion{
    return new AutoEOSversion(data);
  }
  /**
  * @method getModelDefinition
  * @author Julien Ledun
  * @license MIT
  * This method returns an object that represents some of the model
  * definitions.
  **/
  public static getModelDefinition() {
    return {
      name: 'AutoEOSversion',
      plural: 'AutoEOSversions',
      path: 'AutoEOSversions',
      idName: 'EOSname',
      properties: {
        "EOSname": {
          name: 'EOSname',
          type: 'string'
        },
      },
      relations: {
      }
    }
  }
}
