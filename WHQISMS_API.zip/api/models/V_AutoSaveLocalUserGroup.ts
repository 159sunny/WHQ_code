/* tslint:disable */

declare var Object: any;
export interface V_AutoSaveLocalUserGroupInterface {
  "computername"?: string;
  "username"?: string;
  "createdate"?: string;
  "updatedate"?: string;
  "userstate"?: string;
  "userexpire"?: string;
  "setpsdate"?: string;
  "psenddate"?: string;
  "Sitename"?: string;
}

export class V_AutoSaveLocalUserGroup implements V_AutoSaveLocalUserGroupInterface {
  "computername": string;
  "username": string;
  "createdate": string;
  "updatedate": string;
  "userstate": string;
  "userexpire": string;
  "setpsdate": string;
  "psenddate": string;
  "Sitename": string;
  constructor(data?: V_AutoSaveLocalUserGroupInterface) {
    Object.assign(this, data);
  }
  /**
   * The name of the model represented by this $resource,
   * i.e. `V_AutoSaveLocalUserGroup`.
   */
  public static getModelName() {
    return "V_AutoSaveLocalUserGroup";
  }
  /**
  * @method factory
  * @author Jonathan Casarrubias
  * @license MIT
  * This method creates an instance of V_AutoSaveLocalUserGroup for dynamic purposes.
  **/
  public static factory(data: V_AutoSaveLocalUserGroupInterface): V_AutoSaveLocalUserGroup{
    return new V_AutoSaveLocalUserGroup(data);
  }
  /**
  * @method getModelDefinition
  * @author Julien Ledun
  * @license MIT
  * This method returns an object that represents some of the model
  * definitions.
  **/
  public static getModelDefinition() {
    return {
      name: 'V_AutoSaveLocalUserGroup',
      plural: 'V_AutoSaveLocalUserGroups',
      path: 'V_AutoSaveLocalUserGroups',
      idName: 'computername',
      properties: {
        "computername": {
          name: 'computername',
          type: 'string'
        },
        "username": {
          name: 'username',
          type: 'string'
        },
        "createdate": {
          name: 'createdate',
          type: 'string'
        },
        "updatedate": {
          name: 'updatedate',
          type: 'string'
        },
        "userstate": {
          name: 'userstate',
          type: 'string'
        },
        "userexpire": {
          name: 'userexpire',
          type: 'string'
        },
        "setpsdate": {
          name: 'setpsdate',
          type: 'string'
        },
        "psenddate": {
          name: 'psenddate',
          type: 'string'
        },
        "Sitename": {
          name: 'Sitename',
          type: 'string'
        },
      },
      relations: {
      }
    }
  }
}
