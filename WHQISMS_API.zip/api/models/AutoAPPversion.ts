/* tslint:disable */

declare var Object: any;
export interface AutoAPPversionInterface {
  "APPname"?: string;
  "APPnameKey"?: string;
}

export class AutoAPPversion implements AutoAPPversionInterface {
  "APPname": string;
  "APPnameKey": string;
  constructor(data?: AutoAPPversionInterface) {
    Object.assign(this, data);
  }
  /**
   * The name of the model represented by this $resource,
   * i.e. `AutoAPPversion`.
   */
  public static getModelName() {
    return "AutoAPPversion";
  }
  /**
  * @method factory
  * @author Jonathan Casarrubias
  * @license MIT
  * This method creates an instance of AutoAPPversion for dynamic purposes.
  **/
  public static factory(data: AutoAPPversionInterface): AutoAPPversion{
    return new AutoAPPversion(data);
  }
  /**
  * @method getModelDefinition
  * @author Julien Ledun
  * @license MIT
  * This method returns an object that represents some of the model
  * definitions.
  **/
  public static getModelDefinition() {
    return {
      name: 'AutoAPPversion',
      plural: 'AutoAPPversions',
      path: 'AutoAPPversions',
      idName: 'APPname',
      properties: {
        "APPname": {
          name: 'APPname',
          type: 'string'
        },
        "APPnameKey": {
          name: 'APPnameKey',
          type: 'string'
        },
      },
      relations: {
      }
    }
  }
}
