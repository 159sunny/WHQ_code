/* tslint:disable */

declare var Object: any;
export interface V_AutoWINversionInterface {
  "WINnameKey"?: string;
}

export class V_AutoWINversion implements V_AutoWINversionInterface {
  "WINnameKey": string;
  constructor(data?: V_AutoWINversionInterface) {
    Object.assign(this, data);
  }
  /**
   * The name of the model represented by this $resource,
   * i.e. `V_AutoWINversion`.
   */
  public static getModelName() {
    return "V_AutoWINversion";
  }
  /**
  * @method factory
  * @author Jonathan Casarrubias
  * @license MIT
  * This method creates an instance of V_AutoWINversion for dynamic purposes.
  **/
  public static factory(data: V_AutoWINversionInterface): V_AutoWINversion{
    return new V_AutoWINversion(data);
  }
  /**
  * @method getModelDefinition
  * @author Julien Ledun
  * @license MIT
  * This method returns an object that represents some of the model
  * definitions.
  **/
  public static getModelDefinition() {
    return {
      name: 'V_AutoWINversion',
      plural: 'V_AutoWINversions',
      path: 'V_AutoWINversions',
      idName: 'WINnameKey',
      properties: {
        "WINnameKey": {
          name: 'WINnameKey',
          type: 'string'
        },
      },
      relations: {
      }
    }
  }
}
