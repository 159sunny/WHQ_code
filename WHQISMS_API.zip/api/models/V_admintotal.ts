/* tslint:disable */

declare var Object: any;
export interface V_admintotalInterface {
  "computername"?: string;
  "admintotal"?: string;
  "Sitename"?: string;
}

export class V_admintotal implements V_admintotalInterface {
  "computername": string;
  "admintotal": string;
  "Sitename": string;
  constructor(data?: V_admintotalInterface) {
    Object.assign(this, data);
  }
  /**
   * The name of the model represented by this $resource,
   * i.e. `V_admintotal`.
   */
  public static getModelName() {
    return "V_admintotal";
  }
  /**
  * @method factory
  * @author Jonathan Casarrubias
  * @license MIT
  * This method creates an instance of V_admintotal for dynamic purposes.
  **/
  public static factory(data: V_admintotalInterface): V_admintotal{
    return new V_admintotal(data);
  }
  /**
  * @method getModelDefinition
  * @author Julien Ledun
  * @license MIT
  * This method returns an object that represents some of the model
  * definitions.
  **/
  public static getModelDefinition() {
    return {
      name: 'V_admintotal',
      plural: 'V_admintotals',
      path: 'V_admintotals',
      idName: 'computername',
      properties: {
        "computername": {
          name: 'computername',
          type: 'string'
        },
        "admintotal": {
          name: 'admintotal',
          type: 'string'
        },
        "Sitename": {
          name: 'Sitename',
          type: 'string'
        },
      },
      relations: {
      }
    }
  }
}
