/* tslint:disable */

declare var Object: any;
export interface V_AutoAPPnamekeyInterface {
  "APPnameKey"?: string;
}

export class V_AutoAPPnamekey implements V_AutoAPPnamekeyInterface {
  "APPnameKey": string;
  constructor(data?: V_AutoAPPnamekeyInterface) {
    Object.assign(this, data);
  }
  /**
   * The name of the model represented by this $resource,
   * i.e. `V_AutoAPPnamekey`.
   */
  public static getModelName() {
    return "V_AutoAPPnamekey";
  }
  /**
  * @method factory
  * @author Jonathan Casarrubias
  * @license MIT
  * This method creates an instance of V_AutoAPPnamekey for dynamic purposes.
  **/
  public static factory(data: V_AutoAPPnamekeyInterface): V_AutoAPPnamekey{
    return new V_AutoAPPnamekey(data);
  }
  /**
  * @method getModelDefinition
  * @author Julien Ledun
  * @license MIT
  * This method returns an object that represents some of the model
  * definitions.
  **/
  public static getModelDefinition() {
    return {
      name: 'V_AutoAPPnamekey',
      plural: 'V_AutoAPPnamekeys',
      path: 'V_AutoAPPnamekeys',
      idName: 'APPnameKey',
      properties: {
        "APPnameKey": {
          name: 'APPnameKey',
          type: 'string'
        },
      },
      relations: {
      }
    }
  }
}
