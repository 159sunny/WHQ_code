/* tslint:disable */

declare var Object: any;
export interface V_UltiomServertotalInterface {
  "ComputerName"?: string;
  "osversion"?: string;
  "updatedate"?: Date;
  "cpu"?: string;
  "memory"?: string;
  "hdddrivesname"?: string;
  "hddsize"?: string;
  "Sitename"?: string;
}

export class V_UltiomServertotal implements V_UltiomServertotalInterface {
  "ComputerName": string;
  "osversion": string;
  "updatedate": Date;
  "cpu": string;
  "memory": string;
  "hdddrivesname": string;
  "hddsize": string;
  "Sitename": string;
  constructor(data?: V_UltiomServertotalInterface) {
    Object.assign(this, data);
  }
  /**
   * The name of the model represented by this $resource,
   * i.e. `V_UltiomServertotal`.
   */
  public static getModelName() {
    return "V_UltiomServertotal";
  }
  /**
  * @method factory
  * @author Jonathan Casarrubias
  * @license MIT
  * This method creates an instance of V_UltiomServertotal for dynamic purposes.
  **/
  public static factory(data: V_UltiomServertotalInterface): V_UltiomServertotal{
    return new V_UltiomServertotal(data);
  }
  /**
  * @method getModelDefinition
  * @author Julien Ledun
  * @license MIT
  * This method returns an object that represents some of the model
  * definitions.
  **/
  public static getModelDefinition() {
    return {
      name: 'V_UltiomServertotal',
      plural: 'V_UltiomServertotals',
      path: 'V_UltiomServertotals',
      idName: 'ComputerName',
      properties: {
        "ComputerName": {
          name: 'ComputerName',
          type: 'string'
        },
        "osversion": {
          name: 'osversion',
          type: 'string'
        },
        "updatedate": {
          name: 'updatedate',
          type: 'Date'
        },
        "cpu": {
          name: 'cpu',
          type: 'string'
        },
        "memory": {
          name: 'memory',
          type: 'string'
        },
        "hdddrivesname": {
          name: 'hdddrivesname',
          type: 'string'
        },
        "hddsize": {
          name: 'hddsize',
          type: 'string'
        },
        "Sitename": {
          name: 'Sitename',
          type: 'string'
        },
      },
      relations: {
      }
    }
  }
}
