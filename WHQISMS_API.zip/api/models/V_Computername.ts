/* tslint:disable */

declare var Object: any;
export interface V_ComputernameInterface {
  "computername"?: string;
  "Sitename"?: string;
}

export class V_Computername implements V_ComputernameInterface {
  "computername": string;
  "Sitename": string;
  constructor(data?: V_ComputernameInterface) {
    Object.assign(this, data);
  }
  /**
   * The name of the model represented by this $resource,
   * i.e. `V_Computername`.
   */
  public static getModelName() {
    return "V_Computername";
  }
  /**
  * @method factory
  * @author Jonathan Casarrubias
  * @license MIT
  * This method creates an instance of V_Computername for dynamic purposes.
  **/
  public static factory(data: V_ComputernameInterface): V_Computername{
    return new V_Computername(data);
  }
  /**
  * @method getModelDefinition
  * @author Julien Ledun
  * @license MIT
  * This method returns an object that represents some of the model
  * definitions.
  **/
  public static getModelDefinition() {
    return {
      name: 'V_Computername',
      plural: 'V_Computernames',
      path: 'V_Computernames',
      idName: 'computername',
      properties: {
        "computername": {
          name: 'computername',
          type: 'string'
        },
        "Sitename": {
          name: 'Sitename',
          type: 'string'
        },
      },
      relations: {
      }
    }
  }
}
