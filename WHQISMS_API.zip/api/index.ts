/* tslint:disable */
/**
* @module SDKModule
* @author Jonathan Casarrubias <t:@johncasarrubias> <gh:jonathan-casarrubias>
* @license MIT 2016 Jonathan Casarrubias
* @version 2.1.0
* @description
* The SDKModule is a generated Software Development Kit automatically built by
* the LoopBack SDK Builder open source module.
*
* The SDKModule provides Angular 2 >= RC.5 support, which means that NgModules
* can import this Software Development Kit as follows:
*
*
* APP Route Module Context
* ============================================================================
* import { NgModule }       from '@angular/core';
* import { BrowserModule }  from '@angular/platform-browser';
* // App Root 
* import { AppComponent }   from './app.component';
* // Feature Modules
* import { SDK[Browser|Node|Native]Module } from './shared/sdk/sdk.module';
* // Import Routing
* import { routing }        from './app.routing';
* @NgModule({
*  imports: [
*    BrowserModule,
*    routing,
*    SDK[Browser|Node|Native]Module.forRoot()
*  ],
*  declarations: [ AppComponent ],
*  bootstrap:    [ AppComponent ]
* })
* export class AppModule { }
*
**/
import { ErrorHandler } from './services/core/error.service';
import { LoopBackAuth } from './services/core/auth.service';
import { LoggerService } from './services/custom/logger.service';
import { SDKModels } from './services/custom/SDKModels';
import { InternalStorage, SDKStorage } from './storage/storage.swaps';
import { HttpClientModule } from '@angular/common/http';
import { CommonModule } from '@angular/common';
import { NgModule, ModuleWithProviders } from '@angular/core';
import { CookieBrowser } from './storage/cookie.browser';
import { StorageBrowser } from './storage/storage.browser';
import { UserApi } from './services/custom/User';
import { V_AutoSaveLocalUserGroupApi } from './services/custom/V_AutoSaveLocalUserGroup';
import { V_AutoCompareComputerInfoApi } from './services/custom/V_AutoCompareComputerInfo';
import { V_specificAppApi } from './services/custom/V_specificApp';
import { V_AutoSavePatchInfoApi } from './services/custom/V_AutoSavePatchInfo';
import { ACVUserAuthorityApi } from './services/custom/ACVUserAuthority';
import { AutoEOSversionApi } from './services/custom/AutoEOSversion';
import { AutoAPPversionApi } from './services/custom/AutoAPPversion';
import { V_AutoOfcversionApi } from './services/custom/V_AutoOfcversion';
import { V_AutoAPPnamekeyApi } from './services/custom/V_AutoAPPnamekey';
import { V_AutoWINversionApi } from './services/custom/V_AutoWINversion';
import { AutoWINversionApi } from './services/custom/AutoWINversion';
import { V_admintotalApi } from './services/custom/V_admintotal';
import { V_admintotaldaybeforeApi } from './services/custom/V_admintotaldaybefore';
import { V_UltiomServertotalApi } from './services/custom/V_UltiomServertotal';
import { V_TwoUltiomServertotalApi } from './services/custom/V_TwoUltiomServertotal';
import { V_ComputernameApi } from './services/custom/V_Computername';
/**
* @module SDKBrowserModule
* @description
* This module should be imported when building a Web Application in the following scenarios:
*
*  1.- Regular web application
*  2.- Angular universal application (Browser Portion)
*  3.- Progressive applications (Angular Mobile, Ionic, WebViews, etc)
**/
@NgModule({
  imports:      [ CommonModule, HttpClientModule ],
  declarations: [ ],
  exports:      [ ],
  providers:    [
    ErrorHandler
  ]
})
export class SDKBrowserModule {
  static forRoot(internalStorageProvider: any = {
    provide: InternalStorage,
    useClass: CookieBrowser
  }): ModuleWithProviders {
    return {
      ngModule  : SDKBrowserModule,
      providers : [
        LoopBackAuth,
        LoggerService,
        SDKModels,
        UserApi,
        V_AutoSaveLocalUserGroupApi,
        V_AutoCompareComputerInfoApi,
        V_specificAppApi,
        V_AutoSavePatchInfoApi,
        ACVUserAuthorityApi,
        AutoEOSversionApi,
        AutoAPPversionApi,
        V_AutoOfcversionApi,
        V_AutoAPPnamekeyApi,
        V_AutoWINversionApi,
        AutoWINversionApi,
        V_admintotalApi,
        V_admintotaldaybeforeApi,
        V_UltiomServertotalApi,
        V_TwoUltiomServertotalApi,
        V_ComputernameApi,
        internalStorageProvider,
        { provide: SDKStorage, useClass: StorageBrowser }
      ]
    };
  }
}
/**
* Have Fun!!!
* - Jon
**/
export * from './models/index';
export * from './services/index';
export * from './lb.config';
export * from './storage/storage.swaps';
export { CookieBrowser } from './storage/cookie.browser';
export { StorageBrowser } from './storage/storage.browser';

