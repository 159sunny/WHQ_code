'use strict';

module.exports = function(Autoappversion) {

};
