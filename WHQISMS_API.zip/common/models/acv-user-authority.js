'use strict';

module.exports = function(Acvuserauthority) {

};
