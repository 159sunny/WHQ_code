'use strict';

module.exports = function(Autoappnamekey) {

};
