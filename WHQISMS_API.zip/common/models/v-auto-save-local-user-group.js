'use strict';

module.exports = function(Vautosavelocalusergroup) {
  Vautosavelocalusergroup.Localcounttotal = (total, callback) => {
    var connt = Vautosavelocalusergroup.dataSource;
    var sql = "SELECT count(distinct computername) FROM v_AutoSaveLocalUserGroup where Sitename = '" + total + "' and convert(VARCHAR(10),setpsdate,120) < convert(VARCHAR(10),dateadd(dd,-180,getdate()),120)";
    // console.log('sql:' + sql);
    connt.connector.execute(sql, function(err, response) {
        callback(null, response);
    });
};


Vautosavelocalusergroup.datalistpassword = (total, callback) => {
  var connt = Vautosavelocalusergroup.dataSource;
  var sql = "SELECT distinct computername,username,convert(varchar(100),setpsdate,23) as setpsdate,sitename FROM v_AutoSaveLocalUserGroup where Sitename = '" + total + "' and convert(VARCHAR(10),setpsdate,120) < convert(VARCHAR(10),dateadd(dd,-180,getdate()),120)";
  // console.log('sql:' + sql);
  connt.connector.execute(sql, function(err, response) {
      callback(null, response);
  });
};


Vautosavelocalusergroup.datalistpasswordAll = (site, callback) => {
  var connt = Vautosavelocalusergroup.dataSource;
  console.log(site['site']);
  var sql = "SELECT distinct computername,username,convert(varchar(100),setpsdate,23) as setpsdate,sitename FROM v_AutoSaveLocalUserGroup where Sitename in( " + site['site'] +") and convert(VARCHAR(10),setpsdate,120) < convert(VARCHAR(10),dateadd(dd,-180,getdate()),120)";
  // console.log('sql:' + sql);
  connt.connector.execute(sql, function(err, response) {
      callback(null, response);
  });
};



Vautosavelocalusergroup.remoteMethod('datalistpasswordAll', {
  http: {
      path: '/datalistpasswordAll',
      verb: 'post',
  },
  accepts: {
      arg: 'site',
      type: 'object',
      http: {
          source: 'body',
      },
      required: false,
  },
  returns: {
      arg: 'counts',
      type: 'object',
  },
});
Vautosavelocalusergroup.remoteMethod('datalistpassword', {
  http: {
      path: '/datalistpassword',
      verb: 'post',
  },
  accepts: {
      arg: 'total',
      type: 'string',
      http: {
          source: 'body',
      },
      required: false,
  },
  returns: {
      arg: 'counts',
      type: 'object',
  },
});




Vautosavelocalusergroup.remoteMethod('Localcounttotal', {
  http: {
      path: '/Localcounttotal',
      verb: 'post',
  },
  accepts: {
      arg: 'total',
      type: 'string',
      http: {
          source: 'body',
      },
      required: false,
  },
  returns: {
      arg: 'counts',
      type: 'object',
  },
});

};
