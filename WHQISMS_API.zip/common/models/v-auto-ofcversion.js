'use strict';

module.exports = function(Vautoofcversion) {

};
