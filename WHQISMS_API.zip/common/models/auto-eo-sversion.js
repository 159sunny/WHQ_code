'use strict';

module.exports = function(Autoeosversion) {




};
